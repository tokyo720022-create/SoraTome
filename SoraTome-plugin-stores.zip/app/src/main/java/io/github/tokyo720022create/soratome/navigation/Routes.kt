package io.github.tokyo720022create.soratome.navigation

object Routes {
    const val LIBRARY = "library"
    const val HISTORY = "history"
    const val BROWSE = "browse"
    const val PROFILE = "profile"

    const val SERIES_DETAILS = "browse/details"
    const val READER = "reader"

    const val SETTINGS = "settings"
    const val SETTINGS_APPEARANCE = "settings/appearance"
    const val SETTINGS_LIBRARY = "settings/library"
    const val SETTINGS_READER = "settings/reader"
    const val SETTINGS_DOWNLOADS = "settings/downloads"
    const val SETTINGS_TRACKING = "settings/tracking"
    const val SETTINGS_BROWSE = "settings/browse"
    const val SETTINGS_BROWSE_STORES = "settings/browse/stores"
    const val SETTINGS_BROWSE_PLUGINS = "settings/browse/plugins"
    const val SETTINGS_BROWSE_REPOSITORY = "settings/browse/repository/{index}"
    const val SETTINGS_DATA = "settings/data"
    const val SETTINGS_ABOUT = "settings/about"

    fun browseRepository(index: Int) = "settings/browse/repository/$index"
}
